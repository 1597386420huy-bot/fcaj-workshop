---
title: "Deploy Amazon RDS MySQL"
weight: 4
chapter: false
pre: "5.4. "
---

## Contents

1. [Create DB subnet group and RDS](5.4.1-Database/)
2. [Prepare MySQL data](5.4.2-Import/)
