---
title: "Deploy Spring Boot on EC2"
weight: 5
chapter: false
pre: "5.5. "
---

## Contents

1. [Launch EC2 and install dependencies](5.5.1-Instance/)
2. [Create the Cognito user pool for Backend](5.5.2-Cognito-Bootstrap/)
3. [Build and run Backend with systemd](5.5.3-Backend/)
